# Quick Start

- git clone REPO

- pip install youtube_transcript_api

- cp env.example .env

- write Google Youtube Data API 3 in .env

- python3 transcript.py --channel "David Bombal" --maxRequests 10